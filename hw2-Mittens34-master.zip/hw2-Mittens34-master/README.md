HW2 Created

my locks are implemented in the OrderThread and ScheduleThread classes. There are three locks for running the order thread, running the schedule thread and also sending a driver thread. 
